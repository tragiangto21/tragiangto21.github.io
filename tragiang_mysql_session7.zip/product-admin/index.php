<?php
require_once 'Database.php';
$db = Database::getInstance()->getConnection();

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
// Use LEFT JOIN to include all products even without category
$sql = "SELECT p.id, p.name, p.price, p.stock, c.category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE 1";

$params = [];

if ($search != '') {
    $sql .= " AND p.name LIKE :search";
    $params[':search'] = "%$search%";
}

if ($category != '') {
    $sql .= " AND p.category_id = :category";
    $params[':category'] = $category;
}
// Use prepared statement to prevent SQL Injection
$stmt = $db->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$catStmt = $db->query("SELECT * FROM categories");
$categories = $catStmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<body>

<h2>Product Admin</h2>

<form method="GET">
    <input type="text" name="search" placeholder="Search..." value="<?= $search ?>">

    <select name="category">
        <option value="">All</option>
        <?php foreach ($categories as $c): ?>
            <option value="<?= $c['id'] ?>">
                <?= $c['category_name'] ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit">Filter</button>
</form>

<table border="1">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Price</th>
    <th>Category</th>
    <th>Stock</th>
</tr>

<?php foreach ($products as $p): ?>
<tr <?= $p['stock'] < 10 ? 'style="background:red;"' : '' ?>>
    <td><?= $p['id'] ?></td>
    <td><?= $p['name'] ?></td>
    <td><?= $p['price'] ?></td>
    <td><?= $p['category_name'] ?></td>
    <td><?= $p['stock'] ?></td>
</tr>
<?php endforeach; ?>

</table>

</body>
</html>
